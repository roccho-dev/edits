{ root }:
{
  description = "Locked Herdr, Vim, and HQ proof composition";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/0ae2bc1419c3f345984c2629e72e7a631820fa4d";
    go-nixpkgs.url = "github:NixOS/nixpkgs/cbb826608f7d081948eeb4ea0211b0cbd867b9d1";
    vim-src = {
      url = "github:vim/vim/v9.2.0478";
      flake = false;
    };
    hq = {
      url = "github:roccho-dev/hq/779a298f4efcff8df60205aaf973cb224388a82b";
      flake = false;
    };
    yegappan-lsp = {
      url = "github:yegappan/lsp/989016ae2ae4cbf304a9ca29478f47fec794493f";
      flake = false;
    };
  };

  outputs = inputs@{ self, nixpkgs, go-nixpkgs, vim-src, hq, yegappan-lsp, ... }:
    let
      system = "x86_64-linux";
      edits-src = inputs.editsSource.outPath;
      editsRevision = if inputs.editsSource ? rev then inputs.editsSource.rev else "unknown";
      editsTag = if builtins.stringLength editsRevision >= 12 then builtins.substring 0 12 editsRevision else "dirty";
      interactiveDirtyIdentity = builtins.hashString "sha256" (builtins.concatStringsSep "\n" [
        (builtins.readFile (root + "/flake.nix"))
        (builtins.readFile (root + "/flake.lock"))
        (builtins.readFile (root + "/flake.parts/00.nix"))
        (builtins.readFile (root + "/flake.parts/01.nix"))
        (builtins.readFile (root + "/default-world.jsonl"))
        (builtins.readFile (root + "/run-edits.sh"))
        (builtins.readFile (root + "/run-edits-smoke.sh"))
      ]);
      interactiveSourceIdentity = if self ? dirtyRev then interactiveDirtyIdentity else if self ? rev then self.rev else interactiveDirtyIdentity;
      interactiveTag = (if self ? dirtyRev || !(self ? rev) then "dirty-" else "git-") + builtins.substring 0 12 interactiveSourceIdentity;
      hqRevision = if hq ? rev then hq.rev else "unknown";
      source-manifest = builtins.toFile "vim-nix-source.json" (builtins.toJSON {
        schema = "edits.vim-nix-source/1";
        editsRevision = editsRevision;
        hqRevision = hqRevision;
        yegappanLspRevision = if yegappan-lsp ? rev then yegappan-lsp.rev else "unknown";
        vimRevision = if vim-src ? rev then vim-src.rev else "unknown";
      });
      pkgs = import nixpkgs { inherit system; };
      goPkgs = import go-nixpkgs { inherit system; };
      go123 = assert goPkgs.go_1_23.version == "1.23.12"; goPkgs.go_1_23;
      herdr = assert pkgs.herdr.version == "0.8.0"; pkgs.herdr;
      herdr-proof-config = pkgs.writeText "herdr-proof-config.toml" ''
        onboarding = false
      '';

      vim = pkgs.vim.overrideAttrs (old: {
        pname = "vim";
        version = "9.2.0478";
        src = vim-src;
        postInstall = (old.postInstall or "") + ''
          test -d "$out/share/vim/vim92"
          "$out/bin/vim" -Nu NONE -n -i NONE -es \
            '+if v:version != 902 || !has("patch-9.2.478") || !has("vim9script") || !has("channel") || !has("timers") || !has("popupwin") || !has("insert_expand") || !has("multi_byte") || !has("terminal") | cquit 1 | endif' \
            '+quitall!'
        '';
      });

      hq-binaries = pkgs.stdenvNoCC.mkDerivation {
        pname = "hq";
        version = hqRevision;
        src = hq;
        nativeBuildInputs = [ go123 ];
        buildPhase = ''
          runHook preBuild
          export CGO_ENABLED=0 GOPROXY=off HOME="$TMPDIR" GOCACHE="$TMPDIR/go-build"
          go version | grep -Fx 'go version go1.23.12 linux/amd64'
          mkdir -p "$TMPDIR/bin"
          go test ./...
          go build -trimpath -o "$TMPDIR/bin/hq" ./cmd/hq
          go build -trimpath -o "$TMPDIR/bin/hq-worker" ./cmd/hq-worker
          go build -trimpath -o "$TMPDIR/bin/hq-worker-proof-provider" ./cmd/hq-worker-proof-provider
          runHook postBuild
        '';
        installPhase = ''
          runHook preInstall
          install -Dm755 "$TMPDIR/bin/hq" "$out/bin/hq"
          install -Dm755 "$TMPDIR/bin/hq-worker" "$out/bin/hq-worker"
          install -Dm755 "$TMPDIR/bin/hq-worker-proof-provider" "$out/bin/hq-worker-proof-provider"
          runHook postInstall
        '';
      };

      hq-vim = pkgs.runCommand "hq-vim" { } ''
        install -Dm644 ${builtins.path {
          name = "hq.vim";
          path = edits-src + "/packages/hq-vim/plugin/hq.vim";
        }} "$out/plugin/hq.vim"
        install -Dm644 ${builtins.path {
          name = "hq-autoload.vim";
          path = edits-src + "/packages/hq-vim/autoload/hq.vim";
        }} "$out/autoload/hq.vim"
        cp -R ${edits-src + "/packages/hq-vim/testdata"} "$out/testdata"
      '';

      yegappan-lsp-patched = pkgs.applyPatches {
        name = "yegappan-lsp-989016ae-unicode";
        src = yegappan-lsp;
        patches = [ (root + "/yegappan-lsp-unicode.patch") ];
      };

      yegappan-lsp-runtime = pkgs.runCommand "yegappan-lsp" { } ''
        cp -R ${yegappan-lsp-patched} "$out"
        chmod -R u+w "$out"
      '';

      hq-vim-proof-runner = pkgs.stdenvNoCC.mkDerivation {
        pname = "hq-vim-proof-runner";
        version = editsRevision;
        src = edits-src;
        nativeBuildInputs = [ go123 ];
        buildPhase = ''
          runHook preBuild
          export CGO_ENABLED=0 GOPROXY=off HOME="$TMPDIR" GOCACHE="$TMPDIR/go-build"
          cd packages/hq-vim
          VIM_EXE=${vim}/bin/vim \
            VIM9_LSP_PATH=${yegappan-lsp-runtime} \
            go test ./...
          go test -c -trimpath -o "$TMPDIR/hq-vim.test" .
          go build -trimpath -o "$TMPDIR/hq-vim-smoke" ./cmd/hq-vim-smoke
          runHook postBuild
        '';
        installPhase = ''
          runHook preInstall
